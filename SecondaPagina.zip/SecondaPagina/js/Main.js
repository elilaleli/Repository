const NOME1 = "Dizzy";
const NOME2 = "Mido";

let n1 = 3; //let -> evita che si vadano a riscrivere più variabili con lo stesso nome = più sicuro di 'var'
let n2 = 3;

if (n1 == n2)
{
    alert('Sono uguali di valore!');
    if (n1 === n2) //=== -> confronta sia il valore che la tipologia di variabile
    {
        alert('Sono uguali anche di tipologia!');
    }
}
else
{
    alert('Non sono uguali');
}

//PROMPT: è un pop-up con casella di testo.
let numero = prompt('Inserisci un valore: ');
let somma = 0;

for (let i=1; i<numero; i++)
{
    somma += i;
}
document.write(risultato); //stampa a schermo

if ((risultato%2) == 0)
{
    alert('Il numero è PARI');
}
else
{
    alert('Il numero è DISPARI');
}