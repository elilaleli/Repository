
let somma = 0;
let raccoglitore;
let n;

do
{
    n = prompt('Inserisci un Numero (premi zero per terminare)');
    if (n!='0')
    {
        raccoglitore = n + ', ';
        somma += n;
    }
}
while(n != '0');

document.write('Somma: ' + somma + '<br>' + raccoglitore);
