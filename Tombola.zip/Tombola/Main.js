
document.write('|');
for (let i=1; i<100; i++)
{
    if (i>='10')
    {
        document.write(' ' + i + ' ' + '|' + ' ');
    }
    else
    {
        document.write(' 0' + i + ' ' + '|' + ' ');
    }
    if (i=='10' || i=='20' || i=='30' || i=='40' || i=='50' || i=='60' || i=='70' || i=='80' || i=='90')
    {
        document.write('<br>' + '|');
    }
}